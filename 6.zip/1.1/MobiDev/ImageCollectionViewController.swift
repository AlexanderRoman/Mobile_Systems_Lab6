//
//  ImageCollectionViewController.swift
//  MobiDev
//
//  Created by Cockerman on 08.05.2021.
//

import UIKit

class CollectionViewCell1: UICollectionViewCell{
    @IBOutlet weak var ImageView1: UIImageView!    
}

class CollectionViewCell3: UICollectionViewCell{
    @IBOutlet weak var ImageView3: UIImageView!
}

var imageNum = 0
var bigOneTime = false
var smallWidth = CGFloat(0.0)
var bigWidth = CGFloat(0.0)


class ImageCollectionViewController: UICollectionViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var images = [URL]()
    let mainURL = URL(string: "https://pixabay.com/api/?key=19193969-87191e5db266905fe8936d565&q=red+cars&image_type=photo&per_page=21")
    var imageURL = URL(string: "")
        
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell1", for: indexPath) as! CollectionViewCell1
        let child = ActivityIndicatorViewController()
        child.view.frame = cell.contentView.frame
        cell.contentView.addSubview(child.view)
        child.view.translatesAutoresizingMaskIntoConstraints = false
        child.view.heightAnchor.constraint(equalTo: cell.contentView.heightAnchor).isActive = true
        child.view.widthAnchor.constraint(equalTo: cell.contentView.widthAnchor).isActive = true
        child.didMove(toParent: self)
        DispatchQueue.global(qos: .userInteractive).async{
            if let data = try? Data(contentsOf: self.images[indexPath.item]){
                if let image = UIImage(data: data){
                    DispatchQueue.main.async{
                        child.willMove(toParent: nil)
                        child.view.removeFromSuperview()
                        child.removeFromParent()
                        cell.ImageView1.image = image
                    }
                }
            }
        }
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
            
        let child = ActivityIndicatorViewController()
        
            addChild(child)
            child.view.frame = view.frame
            view.addSubview(child.view)
            child.didMove(toParent: self)
        
            var text = try! String(contentsOf: self.mainURL!)
            var textArr = text.components(separatedBy: CharacterSet(charactersIn: "[{\"]"))
            
            var iterator = 0
            while iterator < textArr.count{
                if textArr[iterator] == "" || textArr[iterator] == " "{
                    textArr.remove(at: iterator)
                    iterator -= 1
                }
                iterator += 1
            }
            iterator = 0
            
            for i in 0...textArr.count-1{
                if textArr[i] == "webformatURL"{
                    self.images.append(URL(string: textArr[i+2])!)
                }
            }
        
        //navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Add photo", style: UIBarButtonItem.Style.plain, target: self, action: #selector(importPicture))
        
        let layout = collectionViewLayout as! ImageLayout
        layout.delegate = self
        
        DispatchQueue.main.asyncAfter(deadline: .now()+0.1) {
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()
        }
        
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        collectionView.reloadData()
    }
    
    /*@objc func importPicture(){
        let picker = UIImagePickerController()
        picker.allowsEditing = true
        picker.delegate = self
        present(picker, animated: true)
    }*/
    
    /* For Flow
     func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if ((indexPath.item-1) % 7 == 0){
            bigOneTime = true
            bigWidth = (collectionView.frame.width-20)*3/5
            return CGSize(width: bigWidth, height: bigWidth)
        }else{
            bigOneTime = false
            smallWidth = (collectionView.frame.width-20)/5
            return CGSize(width: smallWidth, height: smallWidth)
        }
    }*/
    
    
    /*func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[.editedImage] as? UIImage else {return}
        dismiss(animated: true)
        
        
        images.append(image)
        collectionView.reloadData()
    }*/
        
}

extension ImageCollectionViewController: ImageLayoutDelegate{
    func collectionView(collectionView: UICollectionView, widthForItemAtIndexPath indexPath: IndexPath) -> CGFloat {
        return 100
    }
}
