//
//  ListViewController.swift
//  MobiDev
//
//  Created by Cockerman on 25.04.2021.
//

import UIKit


class MyCell: UITableViewCell {
    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var myLabel: UILabel!
}

class MyCellNoImage: UITableViewCell{
    @IBOutlet weak var myLabel: UILabel!
}


// I paid for this with grades
let book1 = Book(); let book2 = Book(); let book3 = Book(); let book4 = Book(); let book5 = Book(); let book6 = Book(); let book7 = Book(); let book8 = Book(); let book9 = Book(); let book10 = Book(); let book11 = Book(); let book12 = Book(); let book13 = Book(); let book14 = Book(); let book15 = Book(); let book16 = Book(); let book17 = Book(); let book18 = Book(); let book19 = Book(); let book20 = Book(); let book21 = Book(); let book22 = Book(); let book23 = Book(); let book24 = Book(); let book25 = Book(); let book26 = Book(); let book27 = Book(); let book28 = Book(); let book29 = Book();
var wasPressed = false
var numOfBooks = 0
var numOfAddedBooks = 0
var deleteNumCorrection = 0
var bookArr = [book1, book2, book3, book4, book5, book6, book7, book8, book9, book10, book11, book12, book13, book14, book15, book16, book17, book18, book19, book20, book21, book22, book23, book24, book25, book26, book27, book28, book29]
var descIndex = 0
var searching = false
var filteredBookArr = [Book]()
var temp = [Book]()
var alerted = true
var beforeSearch = false
var canBeSelected = true
var searchText = ""
var invalidSymbols = false



class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchResultsUpdating, UISearchBarDelegate  {
           
    @IBOutlet weak var tableView: UITableView!
            
    var addBookTitle: String?
    var addBookSubtitle: String?
    var addBookPrice: String?
    var justAdded: Bool?
    var resultSearchController = UISearchController()
    var text = ""
    var tempS = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        /*let url0 = URL(string: "https://api.itbook.store/1.0/search/ios")
        DispatchQueue.global().async {
            if let text0 = try? String(contentsOf: url0!){
                print(text0)
                DispatchQueue.main.async {
                    text = text0
                }
            }
        }*/
        
        if searchText.count >= 3{
            
        }
                
        
        resultSearchController = ({
                let controller = UISearchController(searchResultsController: nil)
                controller.searchResultsUpdater = self
                controller.obscuresBackgroundDuringPresentation = false
                controller.searchBar.sizeToFit()
                controller.searchBar.enablesReturnKeyAutomatically = false
                controller.searchBar.returnKeyType = UIReturnKeyType.done
                definesPresentationContext = true
                tableView.tableHeaderView = controller.searchBar
                controller.searchBar.delegate = self
                controller.automaticallyShowsCancelButton = false
                return controller
            })()
                                
                
        //TableView:
                
        tableView.dataSource = self
        tableView.delegate = self
        self.view.addSubview(tableView)
        self.tableView.rowHeight = UITableView.automaticDimension
        self.definesPresentationContext = true
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if alerted {return 1}
        if invalidSymbols {return 1}
        return numOfBooks
    }
        
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /*if (numOfBooks == 0 && alerted == false) /*|| (numOfBooks != 0 && searchText == "")*/{
            alerted = true
            tableView.reloadData()
        }*/
        if (bookArr[indexPath.row].image == "") || alerted || invalidSymbols {
            let MyCellNoIm = tableView.dequeueReusableCell(withIdentifier: "MyCellNoImageId", for: indexPath as IndexPath) as! MyCellNoImage
            
            if invalidSymbols{
                MyCellNoIm.myLabel!.text = "You've entered invalid symbols"
                MyCellNoIm.myLabel!.numberOfLines = 10
                canBeSelected = false
                    
                return MyCellNoIm
                
            }else if alerted {
                MyCellNoIm.myLabel!.text = "No items found"
                MyCellNoIm.myLabel!.numberOfLines = 10
                canBeSelected = false
                    
                return MyCellNoIm
                
            }else{
                if bookArr[indexPath.row].subtitle != "No subtitle"{
                    MyCellNoIm.myLabel!.text = bookArr[indexPath.row].title + "\n\n" + bookArr[indexPath.row].subtitle + "\n\n" + bookArr[indexPath.row].price
                }else{
                    MyCellNoIm.myLabel!.text = bookArr[indexPath.row].title + "\n\n" + bookArr[indexPath.row].price
                }
                MyCellNoIm.myLabel!.font = MyCellNoIm.myLabel!.font.withSize(12.0)
                MyCellNoIm.myLabel!.lineBreakMode = NSLineBreakMode.byWordWrapping
                MyCellNoIm.myLabel!.numberOfLines = 10
                
                return MyCellNoIm
            }
        }else{
            let MyCell = tableView.dequeueReusableCell(withIdentifier: "MyCellId", for: indexPath as IndexPath) as! MyCell
            
                if bookArr[indexPath.row].subtitle != "No subtitle"{
                    MyCell.myLabel!.text = bookArr[indexPath.row].title + "\n\n" + bookArr[indexPath.row].subtitle + "\n\n" + bookArr[indexPath.row].price
                }else{
                    MyCell.myLabel!.text = bookArr[indexPath.row].title + "\n\n" + bookArr[indexPath.row].price
                }
                MyCell.myLabel!.font = MyCell.myLabel!.font.withSize(12.0)
                MyCell.myLabel!.lineBreakMode = NSLineBreakMode.byWordWrapping
                MyCell.myLabel!.numberOfLines = 10
                
                
                let imageURL = URL(string: bookArr[indexPath.row].image)
                DispatchQueue.global().async{
                    if let data = try? Data(contentsOf: imageURL!){
                        if let image = UIImage(data: data){
                            DispatchQueue.main.async {
                                MyCell.myImage!.image = image
                            }
                        }
                    }
                }
                
                //MyCell.myImage!.image = UIImage(named: bookArr[indexPath.row].image)!
                MyCell.myImage!.heightAnchor.constraint(equalToConstant: 90.0).isActive = true
                MyCell.myImage!.widthAnchor.constraint(equalToConstant: 70.0).isActive = true
            
                return MyCell
        }
        
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if resultSearchController.isActive == false{
            return true
        }else{ return false }
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if (editingStyle == .delete) {
            if bookArr[indexPath.row].added{
                numOfAddedBooks -= 1
                numOfBooks -= 1
            }else{ numOfBooks -= 1; deleteNumCorrection -= 1 }
            bookArr.remove(at: indexPath.row)
            let book = Book()
            bookArr.append(book)
                
            tableView.reloadData()
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if alerted == false{
            let child = ActivityIndicatorViewController()
            addChild(child)
            child.view.frame = view.frame
            view.addSubview(child.view)
            child.didMove(toParent: self)
            
            let bookURL = URL(string: "https://api.itbook.store/1.0/books/" + bookArr[indexPath.row].isbn13)
            var bookText = ""
            
            bookText = try! String(contentsOf: bookURL!)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                child.willMove(toParent: nil)
                child.view.removeFromSuperview()
                child.removeFromParent()
            }
            
            var bookTextArr = bookText.components(separatedBy: CharacterSet(charactersIn: "[{\"]"))
            for _ in 0...5{
                bookTextArr.remove(at: 0)
            }
            
            var iter = 0
            while iter < bookTextArr.count{
            if bookTextArr[iter] == "" || bookTextArr[iter] == " "{
                    bookTextArr.remove(at: iter)
                    iter -= 1
                }
                iter += 1
            }
            iter = 0
            if bookTextArr[iter] == "title"{
                if bookTextArr[iter + 2] != ","{
                    bookArr[indexPath.row].title = bookTextArr[iter + 2]
                    iter += 4
                }else{ bookArr[indexPath.row].title = "No title"; iter += 3 }
            }
            if bookTextArr[iter] == "subtitle"{
                if bookTextArr[iter + 2] != ","{
                    bookArr[indexPath.row].subtitle = bookTextArr[iter + 2]
                iter += 4
                }else{ bookArr[indexPath.row].subtitle = "No subtitle"; iter += 3 }
            }
            if bookTextArr[iter] == "authors"{
                if bookTextArr[iter + 2] != ","{
                    bookArr[indexPath.row].authors = bookTextArr[iter + 2]
                    iter += 4
                }else{ bookArr[indexPath.row].authors = "No authors"; iter += 3 }
            }
            if bookTextArr[iter] == "publisher"{
                if bookTextArr[iter + 2] != ","{
                    bookArr[indexPath.row].publisher = bookTextArr[iter + 2]
                    iter += 4
                }else{ bookArr[indexPath.row].publisher = "No publisher"; iter += 3 }
            }
            iter += 12
            if bookTextArr[iter] == "pages"{
                if bookTextArr[iter + 2] != ","{
                    bookArr[indexPath.row].pages = bookTextArr[iter + 2]
                    iter += 4
                }else{ bookArr[indexPath.row].pages = "No pages given"; iter += 3 }
            }
            if bookTextArr[iter] == "year"{
                if bookTextArr[iter + 2] != ","{
                    bookArr[indexPath.row].year = bookTextArr[iter + 2]
                    iter += 4
                }else{ bookArr[indexPath.row].year = "No year given"; iter += 3 }
            }
            if bookTextArr[iter] == "rating"{
                if bookTextArr[iter + 2] != ","{
                    bookArr[indexPath.row].rating = bookTextArr[iter + 2]
                        iter += 4
                }else{ bookArr[indexPath.row].rating = "No rating"; iter += 3 }
            }
            if bookTextArr[iter] == "desc"{
                if bookTextArr[iter + 2] != ","{
                    bookArr[indexPath.row].desc = bookTextArr[iter + 2]
                    iter += 4
                }else{ bookArr[indexPath.row].desc = "No description"; iter += 3 }
            }
            if bookTextArr[iter] == "price"{
                if bookTextArr[iter + 2] != ","{
                    bookArr[indexPath.row].price = bookTextArr[iter + 2]
                    iter += 4
                }else{ bookArr[indexPath.row].price = "No price"; iter += 3 }
            }
            if bookTextArr[iter] == "image"{
                if bookTextArr[iter + 2] != "}/n"{
                    bookArr[indexPath.row].image = bookTextArr[iter + 2]
                }else{ bookArr[indexPath.row].image = "No image" }
            }
            
            searching = resultSearchController.isActive
            temp = bookArr
            descIndex = indexPath.row
            performSegue(withIdentifier: "CellSegue", sender: self)
        }
    }
        
    
    func updateSearchResults(for searchController: UISearchController) {
        if searchController.searchBar.text != nil {
            searchText = searchController.searchBar.text!
        }
                
        let characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789. ")
        if searchText.rangeOfCharacter(from: characterset.inverted) != nil {
            invalidSymbols = true
            tableView.reloadData()
        } else { invalidSymbols = false }
        
                
        if searchText.count == 1 {alerted = true; tableView.reloadData()}
        numOfBooks = 0
        if searchController.searchBar.text!.count >= 3 {
            //var text = ""
            //var text0 = ""
            let searchTextArr = searchText.components(separatedBy: " ")
            let child = ActivityIndicatorViewController()
            if tempS != searchText{
                addChild(child)
                child.view.frame = view.frame
                view.addSubview(child.view)
                child.didMove(toParent: self)
            }
            tempS = searchText
            searchText = ""
            
            DispatchQueue.global(qos: .userInteractive).async { [weak self] in
                for i in 0...searchTextArr.count - 1{
                    searchText += searchTextArr[i]
                    if i <= searchTextArr.count-2{
                        searchText += "%20"
                    }
                }
                
                var bookURL: URL?
                if let url = URL(string: "https://api.itbook.store/1.0/search/" + searchText){
                    self?.text = try! String(contentsOf: url)
                    bookURL = url
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now()+0.1) {
                    child.willMove(toParent: nil)
                    child.view.removeFromSuperview()
                    child.removeFromParent()
                }
            
            //let filePath = Bundle.main.path(forResource: "BooksList", ofType: "txt")
            
            //text = try! String(contentsOfFile: filePath!)
            
            //let tempArr = text.components(separatedBy: "{")
            
            /*if let add = justAdded {
                if add == true{
                    numOfAddedBooks += 1
                    justAdded = false
                }
            }*/
            
            
            var textArr = self?.text.components(separatedBy: CharacterSet(charactersIn: "[{\"]"))
            
            var iterator = 0
            while iterator < textArr!.count{
                if textArr![iterator] == "" || textArr![iterator] == " "{
                    textArr!.remove(at: iterator)
                    iterator -= 1
                }
                iterator += 1
            }
            
            if textArr!.count <= 20{
                DispatchQueue.main.async {
                    alerted = true
                    self?.tableView.reloadData()
                }
            }else{
                alerted = false
                for _ in 0...13{
                    textArr!.remove(at: 0)
                }
                textArr!.remove(at: textArr!.count-1)
                
            
                iterator = 0
                numOfBooks = 0
                for i in 0...textArr!.count-1{
                    if textArr![i] == "isbn13"{ bookArr[numOfBooks].isbn13 = textArr![i+2]; numOfBooks += 1}
                }
                if numOfBooks == 0{
                    DispatchQueue.main.async {
                        alerted = true
                        self?.tableView.reloadData()
                    }
                }
                var iter = 0
                                
                //Parsing through txt file and setting the entity properties right away
                func propertySetter(book: Book){
                                                                
                    var bookTextArr = textArr!
                                    
                    if bookTextArr[iter] == "title"{
                        if bookTextArr[iter + 2] != ","{
                            book.title = bookTextArr[iter + 2]
                            iter += 4
                        }else{ book.title = "No title"; iter += 3 }
                    }
                    if bookTextArr[iter] == "subtitle"{
                        if bookTextArr[iter + 2] != ","{
                        book.subtitle = bookTextArr[iter + 2]
                        iter += 4
                        }else{ book.subtitle = "No subtitle"; iter += 3 }
                    }
                    iter += 4
                    if bookTextArr[iter] == "price"{
                        if bookTextArr[iter + 2] != ","{
                            book.price = bookTextArr[iter + 2]
                            iter += 4
                        }else{ book.price = "No price"; iter += 3 }
                    }
                    if bookTextArr[iter] == "image"{
                        if bookTextArr[iter + 2] != "}/n"{
                            book.image = bookTextArr[iter + 2]
                        }else{ book.image = "No image" }
                    }
                    iter += 8
                }
                
            
                        
                var j = 0
                
                if numOfAddedBooks != 0 && self?.addBookTitle != nil {
                    bookArr[numOfBooks-1].title = self!.addBookTitle!
                    bookArr[numOfBooks-1].subtitle = self!.addBookSubtitle!
                    bookArr[numOfBooks-1].price = self!.addBookPrice!
                    bookArr[numOfBooks-1].image = "No image"
                    bookArr[numOfBooks-1].added = true
                }else{
                    while j < numOfBooks {
                        propertySetter(book: bookArr[j])
                        j += 1
                    }
                }
            }
                    alerted = false
                    DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            }
        } else {
            if searchText.count != 1{
                alerted = true
                tableView.reloadData()
            }
        }
    }
    
    
    
    func createActivityIndicatorView() {
        let child = ActivityIndicatorViewController()
        
        addChild(child)
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
        
        DispatchQueue.main.asyncAfter(deadline: .now()+0.2) {
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()
        }
    }
}
