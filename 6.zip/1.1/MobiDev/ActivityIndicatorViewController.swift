//
//  ActivityIndicatorViewController.swift
//  MobiDev
//
//  Created by Cockerman on 20.05.2021.
//

import UIKit

class ActivityIndicatorViewController: UIViewController {
    var dic = UIActivityIndicatorView(style: .whiteLarge)

    override func loadView() {
        view = UIView()
        view.backgroundColor = UIColor(white: 0, alpha: 0.5)

        dic.translatesAutoresizingMaskIntoConstraints = false
        dic.startAnimating()
        view.addSubview(dic)

        dic.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        dic.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
}
