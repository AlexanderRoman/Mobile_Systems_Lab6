//
//  ViewController.swift
//  MobiDev
//
//  Created by Cockermann on 01.04.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

